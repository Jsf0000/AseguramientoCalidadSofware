var app = angular.module("UsersManagement", []);

//Controller Part
app.controller("UserService", function($scope, $http) {
	
	$scope.users=[];
        var method = "GET";
        var url = "http://localhost:8080/UserManagement/rest/UserService/users/1";
        $http({
            method : method,
            url : url,
            headers : {
                'Content-Type' : 'application/json'
            }
        }).then(function successCallback(response) {
            $scope.user=response.data;
        }, function errorCallback(response) {
            console.log(response.statusText);
        });

});